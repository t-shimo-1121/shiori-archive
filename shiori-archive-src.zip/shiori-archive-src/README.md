# 旅行のしおり集（アーカイブ）の作り方

GitHub Pages の本棚アプリ「旅行のしおり集」を組み立てるための一式。
新しいチャットでアーカイブを更新するときは、この zip を添付して「README のとおりに更新して」と頼む。

## ファイル
- template.html … ページ本体。データ（山・宿泊・旅先・施設・デザインの決まりごと）もこの中に直接書いてある
  - PEAKS（山）／STAYS（宿泊）／PREFS・CITIES・ABROAD（旅先）／SPOTS（施設）／DESIGN（デザインタブ）
- extract.py … 各しおりのリポジトリ（/tmp/s/<repo>/index.html）から表紙・タイトル・タブ・色相などを抜き出して data.json を作る
  - 冒頭の E リストに「id, リポジトリ名, ファイル（通常None）, 開始日, 終了日」を1行足すと対象に入る
- data.json … extract.py の出力（表紙は縮小WebPで埋め込み）
- build.py … template.html と data.json から
  - archive.html（Claudeのプレビュー用）
  - site/index.html・sw.js・manifest.webmanifest（GitHub Pages用）を作る
  - 本棚から外すしおりは build.py 冒頭の除外リストに id を入れる
- sw_template.js … 本棚をオフラインで開くためのサービスワーカー
- icon.py / icon-*.png … ホーム画面のアイコン
- extract_one.py … しおり1冊だけを抜き出して data.json に足す（他のリポジトリを clone しなくてよい）。表紙イラストがまだないしおりは仮の表紙になる

## しおりを1冊追加する手順
1. しおりのリポジトリを /tmp/s/ に git clone（https://github.com/t-shimo-1121/<repo>.git）
2. extract.py の E に1行追加 → `python3 extract.py`
3. 必要なら template.html の PEAKS・STAYS・CITIES・PREFS・SPOTS に行を足す
   - 市区町村は「メインのアクティビティをした所」と「泊まった所」だけ。人口・面積は2020年国勢調査
   - 百名山の通算座数は荒島岳16・瑞牆山17・金峰山18（富士山は2回登ったが1座）
4. `python3 build.py` → site/ の index.html・sw.js をアーカイブのリポジトリにアップロード

## 決まりごと
- しおりのURL：https://t-shimo-1121.github.io/<repo>/
- 本棚の中でしおりを全画面表示（左端から右へスワイプで戻る）。しおりは本棚が端末に保存してオフラインでも開ける
- デザインの決まりごとは template.html の DESIGN（アプリの「デザイン」タブと同じ内容）
