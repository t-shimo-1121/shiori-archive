import re, json, base64, io, subprocess, sys
from PIL import Image
S='/tmp/s'
E=[ # id, repo, file, url, start, end, hidden
 ('okutama','251122okutama',None,'2025-11-22','2025-11-24'),
 ('okinawa2512','251228okinawa',None,'2025-12-28','2026-01-03'),
 ('awaji','260221awajishima',None,'2026-02-21','2026-02-23'),
 ('kanagawa','260320kanagawa',None,'2026-03-20','2026-03-22'),
 ('shikoku','260501shikoku',None,'2026-05-01','2026-05-06'),
 ('camp','260626-camp',None,'2026-06-26','2026-06-27'),
 ('hakuba','260717-Nagano',None,'2026-07-17','2026-07-20'),
 ('hawaii','260811Hawaii',None,'2026-08-11','2026-08-17'),
 ('nagoyanara','260917NagoyaNara',None,'2026-09-19','2026-09-23'),
 ('kugami','260926kugamiyama',None,'2026-09-26','2026-09-27'),
 ('fukui','261010fukui',None,'2026-10-10','2026-10-12'),
 ('itoigawa','261018itoigawa',None,'2026-10-18','2026-10-18'),
 ('yamanashi','261120yamanashi',None,'2026-11-20','2026-11-23'),
 ('kyushu','261228kyushu',None,'2026-12-28','2027-01-03'),
 ('nagano27','270220nagano',None,'2027-02-20','2027-02-23'),
 ('taiwan','270430taiwan',None,'2027-04-30','2027-05-05'),
 ('okinawa','271109okinawa',None,'2027-11-09','2027-11-11'),
]
def strip(s): return re.sub(r'<[^>]+>','',s).strip()
out=[]
for id_,repo,fp,st,en in E:
  raw=open(fp or f'{S}/{repo}/index.html').read()
  # cover
  ci=raw.find('class="cover'); m=re.search(r'data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)',raw[ci:])
  img=Image.open(io.BytesIO(base64.b64decode(m.group(2)))).convert('RGB')
  w=520; img=img.resize((w,round(img.height*w/img.width)),Image.LANCZOS)
  b=io.BytesIO(); img.save(b,'WEBP',quality=72); cover='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
  s=re.sub(r'data:image/[a-z]+;base64,[A-Za-z0-9+/=]+','DATA',raw)
  ns=re.sub(r'<svg[\s\S]*?</svg>','<svg/>',s)
  t=None
  for pat in [r'class="cover-cap">\s*<h1>(.*?)</h1>',r'cover-title-overlay">(.*?)</div>',r'class="lead">\s*<h1>(.*?)</h1>',r'<title>(.*?)</title>']:
    mm=re.search(pat,ns,re.S)
    if mm: t=strip(mm.group(1)); break
  t=re.sub(r'\s*\d{4}\.[\d.\-]+$','',t)
  hues={k:int(v) for k,v in re.findall(r'--h-([a-z0-9]+):\s*(\d+)',s)}
  tabs=[strip(re.sub(r'<small>(.*?)</small>',r' \1',x)) for x in re.findall(r'<button[^>]*(?:tab-btn|nav-chip)[^>]*>(.*?)</button>',ns,re.S)]
  mts=[]
  for mm in re.finditer(r'class="stats[^"]*">(.*?)</div>\s*</div>\s*</div>',ns,re.S):
    head=ns[max(0,mm.start()-900):mm.start()]
    ct=re.findall(r'class="card-title">(.*?)</div>',head); cs=re.findall(r'class="card-sub">(.*?)</div>',head)
    cells=[(strip(a),strip(b)) for a,b in re.findall(r'<div class="n">(.*?)</div><div class="l">(.*?)</div>',mm.group(1),re.S)]
    mts.append({'title':strip(ct[-1]) if ct else '','sub':strip(cs[-1]) if cs else '','cells':cells})
  feat={
   'hue':'--h-base' in s,'twoRow':'class="t-dur"' in s,'stats':bool(mts),'cost':'class="ftable"' in s,
   'sun':'class="sun"' in s,'tripMode':'classList.add("trip")' in s,'map':'google.com/maps' in s,
   'fold':'class="fold"' in s,'countdown':'countdown' in s,'pwa':'rel="manifest"' in s,
   'iconSet':s.count('<symbol'),'dark':'prefers-color-scheme: dark' in s,'climb':'i-summit' in s,
  }
  items=len(re.findall(r'class="(?:item|todo-item)"',s))
  rows=len(re.findall(r'class="tl[ "]',s))+len(re.findall(r'class="ev"',s))
  log=subprocess.run(['git','-C',f'{S}/{repo}','log','--format=%cs'],capture_output=True,text=True).stdout.split()
  out.append(dict(id=id_,repo=repo,title=t,start=st,end=en,hues=hues,tabs=tabs,mountains=mts,features=feat,
    items=items,rows=rows,versions=len(log),first=log[-1],last=log[0],kb=round(len(raw)/1024),cover=cover))
  print(id_,t,'|',tabs,'|',[ (x['title'],x['sub'],x['cells']) for x in mts],'|',items,rows,feat['iconSet'],file=sys.stderr)
json.dump(out,open('/home/claude/archive/data.json','w'),ensure_ascii=False)
