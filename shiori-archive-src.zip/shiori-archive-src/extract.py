import re, json, base64, io, subprocess, sys
from PIL import Image
S='/tmp/s'
E=[ # id, repo, file, url, start, end, hidden
 ('tochigi2305','230505tochigi',None,'2023-05-05','2023-05-07'),
 ('toyama','230527toyama',None,'2023-05-27','2023-05-29'),
 ('tochigi','230715tochigi',None,'2023-07-15','2023-07-17'),
 ('usa','230810usa',None,'2023-08-10','2023-08-15'),
 ('shizuoka','230916shizuoka',None,'2023-09-16','2023-09-18'),
 ('osaka2310','231020osaka',None,'2023-10-20','2023-10-22'),
 ('tokyo2312','231230tokyo',None,'2023-12-30','2024-01-02'),
 ('tokyo2402','240223tokyo',None,'2024-02-23','2024-02-25'),
 ('hawaiians','240329hawaiians',None,'2024-03-29','2024-03-30'),
 ('nagatoro','240413nagatoro',None,'2024-04-13','2024-04-14'),
 ('nagoya2405','240502nagoya',None,'2024-05-02','2024-05-06'),
 ('nikkoshirane','240608nikkoshirane',None,'2024-06-08','2024-06-09'),
 ('fuji2407','240713fuji',None,'2024-07-13','2024-07-15'),
 ('singapore','240811singapore',None,'2024-08-11','2024-08-16'),
 ('karamatsu','240831karamatsu',None,'2024-08-31','2024-09-01'),
 ('yokohama','240921yokohama',None,'2024-09-21','2024-09-23'),
 ('iou','241026iou',None,'2024-10-26','2024-10-27'),
 ('hongkong','241228hongkong',None,'2024-12-28','2025-01-02'),
 ('tsukuba','250222tsukuba',None,'2025-02-22','2025-02-24'),
 ('kyushu2505','250502kyushu',None,'2025-05-02','2025-05-06'),
 ('fuji2507','250719fuji',None,'2025-07-19','2025-07-21'),
 ('hokkaido2508','250810hokkaido',None,'2025-08-10','2025-08-16'),
 ('tsubakuro','250823tsubakuro',None,'2025-08-23','2025-08-24'),
 ('tokyo2509','250913tokyo',None,'2025-09-13','2025-09-15'),
 ('osaka2509','250921osaka',None,'2025-09-21','2025-09-23'),
 ('okutama','251122okutama',None,'2025-11-22','2025-11-24'),
 ('okinawa2512','251228okinawa',None,'2025-12-28','2026-01-03'),
 ('awaji','260221awajishima',None,'2026-02-21','2026-02-23'),
 ('kanagawa','260320kanagawa',None,'2026-03-20','2026-03-22'),
 ('shikoku','260501shikoku',None,'2026-05-01','2026-05-06'),
 ('camp','260626-camp',None,'2026-06-26','2026-06-27'),
 ('hakuba','260717-Nagano',None,'2026-07-17','2026-07-20'),
 ('hawaii','260811Hawaii',None,'2026-08-11','2026-08-17'),
 ('nagoyanara','260917NagoyaNara',None,'2026-09-19','2026-09-23'),
 ('kugami','260926kugamiyama',None,'2026-09-26','2026-09-27'),
 ('fukui','261010fukui',None,'2026-10-10','2026-10-12'),
 ('itoigawa','261018itoigawa',None,'2026-10-18','2026-10-18'),
 ('yamanashi','261120yamanashi',None,'2026-11-20','2026-11-23'),
 ('kyushu','261228kyushu',None,'2026-12-28','2027-01-03'),
 ('nagano27','270220nagano',None,'2027-02-20','2027-02-23'),
 ('taiwan','270430taiwan',None,'2027-04-30','2027-05-05'),
 ('okinawa','271109okinawa',None,'2027-11-09','2027-11-11'),
]
def strip(s): return re.sub(r'<[^>]+>','',s).strip()
out=[]
for id_,repo,fp,st,en in E:
  raw=open(fp or f'{S}/{repo}/index.html').read()
  # cover
  ci=raw.find('class="cover'); m=re.search(r'data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)',raw[ci:])
  img=Image.open(io.BytesIO(base64.b64decode(m.group(2)))).convert('RGB')
  w=520; img=img.resize((w,round(img.height*w/img.width)),Image.LANCZOS)
  b=io.BytesIO(); img.save(b,'WEBP',quality=72); cover='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
  s=re.sub(r'data:image/[a-z]+;base64,[A-Za-z0-9+/=]+','DATA',raw)
  ns=re.sub(r'<svg[\s\S]*?</svg>','<svg/>',s)
  t=None
  for pat in [r'class="cover-cap">\s*<h1>(.*?)</h1>',r'cover-title-overlay">(.*?)</div>',r'class="lead">\s*<h1>(.*?)</h1>',r'<title>(.*?)</title>']:
    mm=re.search(pat,ns,re.S)
    if mm: t=strip(mm.group(1)); break
  t=re.sub(r'\s*\d{4}\.[\d.\-]+$','',t)
  hues={k:int(v) for k,v in re.findall(r'--h-([a-z0-9]+):\s*(\d+)',s)}
  tabs=[strip(re.sub(r'<small>(.*?)</small>',r' \1',x)) for x in re.findall(r'<button[^>]*(?:tab-btn|nav-chip)[^>]*>(.*?)</button>',ns,re.S)]
  mts=[]
  for mm in re.finditer(r'class="stats[^"]*">(.*?)</div>\s*</div>\s*</div>',ns,re.S):
    head=ns[max(0,mm.start()-900):mm.start()]
    ct=re.findall(r'class="card-title">(.*?)</div>',head); cs=re.findall(r'class="card-sub">(.*?)</div>',head)
    cells=[(strip(a),strip(b)) for a,b in re.findall(r'<div class="n">(.*?)</div><div class="l">(.*?)</div>',mm.group(1),re.S)]
    mts.append({'title':strip(ct[-1]) if ct else '','sub':strip(cs[-1]) if cs else '','cells':cells})
  feat={
   'hue':'--h-base' in s,'twoRow':'class="t-dur"' in s,'stats':bool(mts),'cost':'class="ftable"' in s,
   'sun':'class="sun"' in s,'tripMode':'classList.add("trip")' in s,'map':'google.com/maps' in s,
   'fold':'class="fold"' in s,'countdown':'countdown' in s,'pwa':'rel="manifest"' in s,
   'iconSet':s.count('<symbol'),'dark':'prefers-color-scheme: dark' in s,'climb':'i-summit' in s,
  }
  items=len(re.findall(r'class="(?:item|todo-item)"',s))
  rows=len(re.findall(r'class="tl[ "]',s))+len(re.findall(r'class="ev"',s))
  log=subprocess.run(['git','-C',f'{S}/{repo}','log','--format=%cs'],capture_output=True,text=True).stdout.split()
  out.append(dict(id=id_,repo=repo,title=t,start=st,end=en,hues=hues,tabs=tabs,mountains=mts,features=feat,
    items=items,rows=rows,versions=len(log),first=log[-1],last=log[0],kb=round(len(raw)/1024),cover=cover))
  print(id_,t,'|',tabs,'|',[ (x['title'],x['sub'],x['cells']) for x in mts],'|',items,rows,feat['iconSet'],file=sys.stderr)
json.dump(out,open('/home/claude/archive/data.json','w'),ensure_ascii=False)
