import re, json, base64, io, subprocess, sys
from PIL import Image
S='/tmp/s'
import sys
E=[tuple(sys.argv[1:3])+((sys.argv[3] if sys.argv[3]!='-' else None),)+tuple(sys.argv[4:6])]
def strip(s): return re.sub(r'<[^>]+>','',s).strip()
out=[]
for id_,repo,fp,st,en in E:
  raw=open(fp or f'{S}/{repo}/index.html').read()
  # cover
  ci=raw.find('class="cover'); m=re.search(r'data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)',raw[ci:])
  if m: img=Image.open(io.BytesIO(base64.b64decode(m.group(2)))).convert('RGB')
  else:  # 表紙イラストがまだない：仮の表紙
    img=Image.new('RGB',(520,390))
    import colorsys
    for y in range(390):
      r,g,b_=colorsys.hls_to_rgb(205/360,.93-.05*y/390,.45)
      for x in range(520): img.putpixel((x,y),(int(r*255),int(g*255),int(b_*255)))
  w=520; img=img.resize((w,round(img.height*w/img.width)),Image.LANCZOS)
  b=io.BytesIO(); img.save(b,'WEBP',quality=72); cover='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
  s=re.sub(r'data:image/[a-z]+;base64,[A-Za-z0-9+/=]+','DATA',raw)
  ns=re.sub(r'<svg[\s\S]*?</svg>','<svg/>',s)
  t=None
  for pat in [r'class="cover-cap">\s*<h1>(.*?)</h1>',r'cover-title-overlay">(.*?)</div>',r'class="lead">\s*<h1>(.*?)</h1>',r'<title>(.*?)</title>']:
    mm=re.search(pat,ns,re.S)
    if mm: t=strip(mm.group(1)); break
  t=re.sub(r'\s*\d{4}\.[\d.\-]+$','',t)
  hues={k:int(v) for k,v in re.findall(r'--h-([a-z0-9]+):\s*(\d+)',s)}
  tabs=[strip(re.sub(r'<small>(.*?)</small>',r' \1',x)) for x in re.findall(r'<button[^>]*(?:tab-btn|nav-chip)[^>]*>(.*?)</button>',ns,re.S)]
  mts=[]
  for mm in re.finditer(r'class="stats[^"]*">(.*?)</div>\s*</div>\s*</div>',ns,re.S):
    head=ns[max(0,mm.start()-900):mm.start()]
    ct=re.findall(r'class="card-title">(.*?)</div>',head); cs=re.findall(r'class="card-sub">(.*?)</div>',head)
    cells=[(strip(a),strip(b)) for a,b in re.findall(r'<div class="n">(.*?)</div><div class="l">(.*?)</div>',mm.group(1),re.S)]
    mts.append({'title':strip(ct[-1]) if ct else '','sub':strip(cs[-1]) if cs else '','cells':cells})
  feat={
   'hue':'--h-base' in s,'twoRow':'class="t-dur"' in s,'stats':bool(mts),'cost':'class="ftable"' in s,
   'sun':'class="sun"' in s,'tripMode':'classList.add("trip")' in s,'map':'google.com/maps' in s,
   'fold':'class="fold"' in s,'countdown':'countdown' in s,'pwa':'rel="manifest"' in s,
   'iconSet':s.count('<symbol'),'dark':'prefers-color-scheme: dark' in s,'climb':'i-summit' in s,
  }
  items=len(re.findall(r'class="(?:item|todo-item)"',s))
  rows=len(re.findall(r'class="tl[ "]',s))+len(re.findall(r'class="ev"',s))
  log=subprocess.run(['git','-C',f'{S}/{repo}','log','--format=%cs'],capture_output=True,text=True).stdout.split() or [__import__('datetime').date.today().isoformat()]
  out.append(dict(id=id_,repo=repo,title=t,start=st,end=en,hues=hues,tabs=tabs,mountains=mts,features=feat,
    items=items,rows=rows,versions=len(log),first=log[-1],last=log[0],kb=round(len(raw)/1024),cover=cover,ph=not m))
  print(id_,t,'|',tabs,'|',[ (x['title'],x['sub'],x['cells']) for x in mts],'|',items,rows,feat['iconSet'],file=sys.stderr)
d=json.load(open('data.json')); d=[x for x in d if x['id']!=E[0][0]]+out
d.sort(key=lambda x:x['start']); json.dump(d,open('data.json','w'),ensure_ascii=False)
