import json
d=[x for x in json.load(open('data.json')) if x['id'] not in ('camp','kugami','itoigawa','okinawa')]
for x in d: x.pop('mountains',None)
js=json.dumps(d,ensure_ascii=False).replace('</','<\\/')
t=open('template.html').read().replace('__DATA__',js)
open('archive.html','w').write(t)
import os; os.makedirs('site',exist_ok=True)
head='<!DOCTYPE html>\n<html lang="ja">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">\n<meta name="robots" content="noindex">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-status-bar-style" content="default">\n<meta name="apple-mobile-web-app-title" content="しおり集">\n<meta name="theme-color" media="(prefers-color-scheme: light)" content="#F3F5F8">\n<meta name="theme-color" media="(prefers-color-scheme: dark)" content="#161B22">\n<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="icon-180.png">\n<link rel="icon" href="icon-192.png">\n<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0}img{max-width:100%}[hidden]{display:none!important}</style>\n'
i=t.find('<div class="wrap">')
sw='<script>if("serviceWorker" in navigator)window.addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){});});</script>\n'
open('site/index.html','w').write(head+t[:i]+sw+'</head>\n<body>\n'+t[i:]+'\n</body>\n</html>\n')
json.dump({"name":"旅行のしおり集","short_name":"しおり集","lang":"ja","start_url":"./","scope":"./","display":"standalone",
  "background_color":"#F3F5F8","theme_color":"#F3F5F8",
  "icons":[{"src":"icon-192.png","sizes":"192x192","type":"image/png"},{"src":"icon-512.png","sizes":"512x512","type":"image/png","purpose":"any maskable"}]},
  open('site/manifest.webmanifest','w'),ensure_ascii=False,indent=1)
import hashlib
ver=hashlib.md5(open('site/index.html','rb').read()).hexdigest()[:8]
open('site/sw.js','w').write(open('sw_template.js').read().replace('__VER__',ver))
