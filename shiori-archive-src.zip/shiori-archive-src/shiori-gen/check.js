const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  for (const scheme of ['light','dark']) {
    const p = await b.newPage({ viewport:{width:390,height:844}, deviceScaleFactor:2, colorScheme:scheme });
    await p.route(/fonts\.(googleapis|gstatic)/, r=>r.abort());
    await p.goto('file://'+process.cwd()+'/out/'+process.argv[2]+'/index.html');
    for (const tab of await p.evaluate(()=>[...document.querySelectorAll('.tab-btn')].map(b=>b.dataset.tab))) {
      await p.click(`.tab-btn[data-tab="${tab}"]`); await p.waitForTimeout(350);
      const bad = await p.evaluate((tab)=>{
        const out=[]; const panel=document.getElementById(tab);
        panel.querySelectorAll('.t-sum,.t-det,.card-title,.ftable td,.note li,.stats .n').forEach(e=>{
          const lh=parseFloat(getComputedStyle(e).lineHeight)||0;
          if (e.matches('.t-sum,.t-det') && e.getBoundingClientRect().height>lh*1.5) out.push('WRAP '+e.textContent);
          if (e.scrollWidth>e.clientWidth+1) out.push('OVER '+e.textContent);
        });
        if (document.documentElement.scrollWidth>390) out.push('PAGE WIDTH '+document.documentElement.scrollWidth);
        return out;
      }, tab);
      console.log(scheme, tab, bad.length?bad:'OK');
      await p.screenshot({path:`shot_${process.argv[2]}_${scheme}_${tab}.png`, fullPage:true});
    }
  }
  await b.close();
})();
