"""しおり生成ライブラリ：奥多摩しおり（251122okutama）の書式をそのまま使い、旅程データだけ差し替える"""
import re, urllib.parse
SRC = '/tmp/s/251122okutama/index.html'

def M(q, label=None):
    return '<a class="map" href="https://www.google.com/maps/search/?api=1&query=%s" target="_blank" rel="noopener">%s</a>' % (urllib.parse.quote(q), label or q)
def hl(s): return '<span class="hl">%s</span>' % s
def warn(s): return '<span class="warn">%s</span>' % s
def mins(t):
    h, m = t.split(':'); return int(h) * 60 + int(m)
def fmt(d): return '%d:%02d' % (d // 60, d % 60)
def yen(n): return '—' if n is None else '{:,}円'.format(n)

def order(rows):
    for s in [r for r in rows if r[0] == 'sun']:
        rows.remove(s); k = 0
        for j, r in enumerate(rows):
            if r[0] != 'sun' and mins(r[0]) <= mins(s[1]): k = j + 1
        rows.insert(k, s)
    return rows

def trail(rows, next_wake=None):
    order(rows)
    tl = [r for r in rows if r[0] != 'sun']
    out = []
    for idx, r in enumerate(rows):
        if r[0] == 'sun':
            _, t, kind, inh = r
            cls = (' set' if kind == 'set' else '') + (' in-hike' if inh else '')
            out.append('        <div class="sun%s" data-t="%s"><div class="s-t">%s</div><div class="s-d"></div><div>%s</div></div>'
                       % (cls, t, t, '日の出' if kind == 'rise' else '日の入'))
            continue
        t, ico, s, det, cls = r[:5]
        i = next(k for k, x in enumerate(tl) if x is r)
        if i + 1 < len(tl): d = mins(tl[i + 1][0]) - mins(t)
        elif next_wake: d = mins(next_wake) + 1440 - mins(t)
        else: d = None
        dur = '—' if d is None else ('' if d < 5 else fmt(d))
        if len(r) > 5: dur = r[5]   # 時差をまたぐ行など、所要を手で指定
        assert dur in ('', '—') or not dur.startswith('-'), (t, s, dur)
        hh, mm = t.split(':')
        out.append('        <div class="tl%s" data-t="%02d:%s"><div class="t-start">%s</div><div class="t-dur">%s</div><div class="t-ico"><svg class="ic"><use href="#%s"/></svg></div><div class="t-sum">%s</div>%s</div>'
                   % (' ' + cls if cls else '', int(hh), mm, t, dur, ico, s, ('<div class="t-det">%s</div>' % det) if det else ''))
    return '\n'.join(out)

def card(n, D):
    mt = ('      <div class="mt">\n        <div class="stats stats-3">%s</div>\n      </div>\n' % ''.join(
        '<div class="s"><div class="n">%s</div><div class="l">%s</div></div>' % c for c in D['stats'])) if D.get('stats') else ''
    return '''  <!-- ══════════ Day%d ══════════ -->
  <div class="tab-panel" id="day%d">
    <div class="card day%d" data-date="%s">
      <div class="card-head">
        <span class="tag only" aria-label="%s"><svg class="ic"><use href="#%s"/></svg></span>
        <div class="card-title">%s</div>
      </div>
%s      <div class="trail">
%s
      </div>
      <div class="note">
        <div class="note-h">この日のポイント</div>
        <ul>
%s
        </ul>
      </div>
    </div>
  </div><!-- /day%d -->
''' % (n, n, n, D['date'], D['aria'], D['icon'], D['title'], mt, trail(D['rows'], D.get('wake')),
       '\n'.join('          <li>%s</li>' % x for x in D['notes']), n)

def ftable(head, rows, sub):
    body = '\n'.join('            <tr><td>%s</td><td>%s</td><td>%s</td></tr>' % (a, b, yen(c)) for a, b, c in rows)
    return '''      <div class="mt">
        <div class="mt-h">%s</div>
        <table class="ftable">
          <thead><tr><th>%s</th><th>%s</th><th>金額</th></tr></thead>
          <tbody>
%s
          </tbody>
          <tfoot><tr><td colspan="2">小計</td><td>%s</td></tr></tfoot>
        </table>
      </div>
''' % (head, sub[0], sub[1], body, yen(sum(c for _, _, c in rows if c) if any(c for _, _, c in rows) else None))

def pack(C):
    parts, tot, expl = [], 0, []
    for head, short, rows in C['costs']:
        sub = ('日程', '宿泊先') if head == '宿泊費' else ('日付', '項目')
        parts.append(ftable(head, rows, sub))
        s = sum(c for _, _, c in rows if c); tot += s
        if s: expl.append('%s%s' % (short, '{:,}円'.format(s)))
    assert tot == C['excel_total'], (tot, C['excel_total'])
    return '''  <!-- ══════════ 準備タブ ══════════ -->
  <div class="tab-panel is-active" id="pack">

    <div class="card pack">
      <div class="card-head">
        <span class="tag only" aria-hidden="true"><svg class="ic"><use href="#i-coin"/></svg></span>
        <div class="card-title">費用</div>
      </div>

%s
      <div class="note">
        <div class="note-h">総額</div>
        <ul>
          <li><span class="hl">%s</span>　%s</li>
          <li>金額の分かっている分だけの合計。%s</li>
        </ul>
      </div>
    </div>

  </div><!-- /pack -->

''' % ('\n'.join(parts), yen(tot), '＋'.join(expl), C['excl'])

def build(C, out):
    src = open(SRC).read()
    head = src[:src.index('<div class="wrap">')]
    tail = src[src.index('</div>\n\n\n<script>'):]
    dates = [D['date'] for D in C['days']]
    n = len(dates)
    head = head.replace('content="奥多摩しおり"', 'content="%s"' % C['apptitle'])
    head = head.replace('["2025-11-22","2025-11-23","2025-11-24"]', '[' + ','.join('"%s"' % d for d in dates) + ']')
    head = head.replace('<title>奥多摩旅行 2025.11.22-24</title>', '<title>%s</title>' % C['doctitle'])
    hues = C['hues']
    head = re.sub(r'・現在の設定：.*', '・現在の設定：base 40 / brand 205 / pack 175 / ' + ' / '.join('d%d %d' % (i + 1, h) for i, (h, _) in enumerate(hues)) + '（仮。表紙が決まったら抽出し直す）', head)
    head = re.sub(r'(  --h-d\d:.*\n)+', ''.join('  --h-d%d:%5d;     /* %s */\n' % (i + 1, h, c) for i, (h, c) in enumerate(hues)), head)
    def rebuild(h, block_re, line):
        m = re.search(block_re, h)
        return h[:m.start()] + ''.join(line.replace('#', str(i)) for i in range(1, n + 1)) + h[m.end():]
    head = rebuild(head, r'(\.tab-btn\.active\.t\d\{background:hsl\(var\(--h-d\d\),46%,36%\);\}\n)+',
                   '.tab-btn.active.t#{background:hsl(var(--h-d#),46%,36%);}\n')
    head = rebuild(head, r'(\.day\d\{--c:hsl\(var\(--h-d\d\),46%,36%\);[^\n]*\n)+',
                   '.day#{--c:hsl(var(--h-d#),46%,36%);--c-bg:hsl(var(--h-d#),45%,94%);--c-tint:hsl(var(--h-d#),45%,97%);}\n')
    head = rebuild(head, r'(  \.day\d\{--c:hsl\(var\(--h-d\d\),50%,64%\);[^\n]*\n)+',
                   '  .day#{--c:hsl(var(--h-d#),50%,64%);--c-bg:hsl(var(--h-d#),26%,18%);--c-tint:hsl(var(--h-d#),26%,16%);}\n')
    tabs = '\n'.join('    <button class="tab-btn t%d" data-tab="day%d" role="tab"%s>%s<small>%s</small></button>'
                     % (i + 1, i + 1, (' aria-label="%s"' % D['tabaria']) if D.get('tabaria') else '', D['tab'], D['place'])
                     for i, D in enumerate(C['days']))
    body = '''<div class="wrap">

  <!-- ══════════ 表紙 ══════════ -->
  <div class="cover">
    <div class="cover-frame">
      <div class="cover-ph">表紙イラスト（後で差し替え）</div>
    </div>
    <div class="cover-cap">
      <h1>%s</h1>
      <div class="date">%s</div>
      <div class="count" id="countdown"></div>
    </div>
  </div>

  <!-- ══════════ タブ ══════════ -->
  <div class="tabs" role="tablist">
    <button class="tab-btn t0 active" data-tab="pack" role="tab">準備<small>費用</small></button>
%s
  </div>


''' % (C['title'], C['daterange'], tabs) + pack(C) + ''.join(card(i + 1, D) for i, D in enumerate(C['days'])) + '\n\n'
    tail = tail.replace("var NS = 'okutama251122_';", "var NS = '%s_';" % C['ns'])
    tail = tail.replace("['2025-11-22','2025-11-23','2025-11-24']", '[' + ','.join("'%s'" % d for d in dates) + ']')
    tail = tail.replace("new Date('2025-11-22T00:00:00')", "new Date('%sT00:00:00')" % dates[0])
    html = head + body + tail
    for bad in ['奥多摩', '2025-11', '⇄', '⇔', 'okutama']:
        assert bad not in html, bad
    open(out, 'w').write(html)
    print('ok', out, len(html))
