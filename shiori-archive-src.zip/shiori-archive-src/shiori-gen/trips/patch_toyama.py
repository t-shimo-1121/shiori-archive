import sys
p=sys.argv[1]
def rep(path, pairs):
    s=open(path).read()
    for a,b in pairs:
        assert s.count(a)==1, (path,a,s.count(a)); s=s.replace(a,b)
    open(path,'w').write(s)
rep(p+'/extract.py',[(" ('tochigi','230715tochigi'"," ('toyama','230527toyama',None,'2023-05-27','2023-05-29'),\n ('tochigi','230715tochigi'")])
rep(p+'/template.html',[
 (' {p:"栃木県",nm:"那須町"',
  ' {p:"富山県",nm:"黒部市",pop:39638,area:426.31,v:"2023.5",r:[["宿泊","宇奈月グランドホテル"],["観光","宇奈月温泉"]],ft:"黒部峡谷と宇奈月温泉。トロッコ電車の始発駅"},\n'
  ' {p:"富山県",nm:"魚津市",pop:40535,area:200.61,v:"2023.5",r:[["観光","魚津水族館・ミラージュランド"]],ft:"蜃気楼の見える町。現存する日本最古の水族館"},\n'
  ' {p:"栃木県",nm:"那須町"'),
 (' {c:"park",nm:"那須ハイランドパーク"',
  ' {c:"park",nm:"ミラージュランド",at:"富山県魚津市",v:"2023.5",tr:"toyama",\n   d:[["見どころ","魚津水族館の隣の遊園地。富山湾と立山連峰を望む大観覧車"]]},\n'
  ' {c:"park",nm:"那須ハイランドパーク"'),
 (' {c:"aqua",nm:"伊豆アニマルキングダム"',
  ' {c:"aqua",nm:"魚津水族館",at:"富山県魚津市",v:"2023.5",tr:"toyama",\n   d:[["開館","1913年（現存する日本最古の水族館）"],["見どころ","富山湾の生き物と、北アルプスの渓流の魚"]]},\n'
  ' {c:"aqua",nm:"伊豆アニマルキングダム"'),
 (' {d:"2023-07-15",t:"tochigi"',
  ' {d:"2023-05-27",t:"toyama",nm:"宇奈月グランドホテル",a:"宇奈月温泉",n:2,kind:"ホテル",p:73700,nt:"2連泊"},\n {d:"2023-07-15",t:"tochigi"'),
])
print('patched')
