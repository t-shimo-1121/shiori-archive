import sys
p=sys.argv[1]
def rep(path, pairs):
    s=open(path).read()
    for a,b in pairs:
        assert s.count(a)==1, (path,a,s.count(a)); s=s.replace(a,b)
    open(path,'w').write(s)
rep(p+'/extract.py',[(" ('osaka2209','220917osaka'"," ('onomichi','190914onomichi',None,'2019-09-14','2019-09-16'),\n ('osaka2209','220917osaka'")])
rep(p+'/template.html',[
 ('{p:"広島県",nm:"福山市",pop:460930,area:518.14,v:"2018.1",r:[["宿泊","リッチモンドホテル福山駅前・ベッセルイン福山駅北口"]],ft:"福山城と鞆の浦、ばらのまち"},',
  '{p:"広島県",nm:"福山市",pop:460930,area:518.14,v:"2018.1",r:[["宿泊","リッチモンドホテル福山駅前・ベッセルイン福山駅北口・カンデオホテルズ福山"]],ft:"福山城と鞆の浦、ばらのまち"},\n'
  ' {p:"広島県",nm:"尾道市",pop:131170,area:285.11,v:"2019.9",r:[["観光","尾道"]],ft:"坂と寺の町。しまなみ海道の本州側の玄関口"'),
 ('{c:"park",nm:"ユニバーサル・スタジオ・ジャパン",at:"大阪府大阪市此花区",v:"2022.9",tr:"osaka2209"','{c:"park",nm:"ユニバーサル・スタジオ・ジャパン",at:"大阪府大阪市此花区",v:"2019.9",tr:"onomichi"'),
 ('{c:"aqua",nm:"海遊館",at:"大阪府大阪市港区（天保山）",v:"2022.9",tr:"osaka2209"','{c:"aqua",nm:"海遊館",at:"大阪府大阪市港区（天保山）",v:"2019.9",tr:"onomichi"'),
 (' {d:"2022-09-17",t:"osaka2209"',
  ' {d:"2019-09-14",t:"onomichi",nm:"カンデオホテルズ福山",a:"福山",n:2,kind:"ホテル",p:25920,nt:"支払済み"},\n {d:"2022-09-17",t:"osaka2209"'),
])
print('patched')
