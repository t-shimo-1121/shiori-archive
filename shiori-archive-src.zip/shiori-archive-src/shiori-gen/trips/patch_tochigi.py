import sys
p=sys.argv[1]
def rep(path, pairs):
    s=open(path).read()
    for a,b in pairs:
        assert s.count(a)==1, (path,a,s.count(a)); s=s.replace(a,b)
    open(path,'w').write(s)
rep(p+'/extract.py',[(" ('usa','230810usa'"," ('tochigi','230715tochigi',None,'2023-07-15','2023-07-17'),\n ('usa','230810usa'")])
rep(p+'/template.html',[
 ('{no:9,nm:"栃木県",cap:"宇都宮市",pop:1933146,area:6408.09,v:"2024.6"','{no:9,nm:"栃木県",cap:"宇都宮市",pop:1933146,area:6408.09,v:"2023.7"'),
 (' {p:"静岡県",nm:"東伊豆町"',
  ' {p:"栃木県",nm:"那須町",pop:23956,area:372.34,v:"2023.7",r:[["観光","NOZARU・那須ハイランドパーク"],["宿泊","ロイヤルホテル那須"]],ft:"那須岳のふもとの高原リゾート。那須御用邸"},\n {p:"静岡県",nm:"東伊豆町"'),
 (' {c:"park",nm:"ディズニーランド・パーク"',
  ' {c:"park",nm:"那須ハイランドパーク",at:"栃木県那須町",v:"2023.7",tr:"tochigi",\n   d:[["見どころ","那須高原の遊園地。ジェットコースターと、ペットと入れるエリア"]]},\n'
  ' {c:"park",nm:"那須の森の空中アスレチック NOZARU",at:"栃木県那須町",v:"2023.7",tr:"tochigi",\n   d:[["見どころ","森の木の上をめぐる空中アスレチック。子ども向けのKOZARU"]]},\n'
  ' {c:"park",nm:"ディズニーランド・パーク"'),
 (' {d:"2023-08-12",t:"usa"',
  ' {d:"2023-07-15",t:"tochigi",nm:"ロイヤルホテル那須",a:"那須高原",n:2,kind:"ホテル",p:139000,nt:"2連泊"},\n {d:"2023-08-12",t:"usa"'),
])
print('patched')
