# しおり生成ツール（Excel → 単一HTML）

奥多摩しおり（251122okutama）の HTML をそのまま型にして、旅程データだけ差し替える。

## 準備
    git clone https://github.com/t-shimo-1121/251122okutama.git /tmp/s/251122okutama
（lib.py の SRC がこのパスを見る）

## 1冊作る
1. trips/ の既存スクリプト（例：motegi.py＝車旅、usa.py＝海外・日付変更線）をコピーして旅程を書く
   - 行：(開始, アイコン, 概要, 詳細, 'stay'/'hike'/'')。6つ目に所要を書くと手動指定（時差をまたぐ便など）
   - 日の出入り：('sun', '18:30', 'rise'|'set', in_hike)。時刻順に自動で並ぶ
   - wake='6:00' で就寝の所要を翌朝の起床まで計算。最終日は wake なし→「—」
   - excel_total に Excel の各日合計を足した値 → 費用表の合計と一致しないと止まる
2. python3 trips/xxx.py out/<repo>/index.html
3. node check.js <repo>（out/<repo>/index.html を 390px・明暗で開き、折り返し・はみ出しを表示。スクショも保存）
4. 日の出入り：sun.py の sun(date, lat, lon, rise=True, tz=9)
5. アーカイブ：trips/patch_xxx.py を参考に template.html・extract.py を置換 → extract_one.py → build.py
